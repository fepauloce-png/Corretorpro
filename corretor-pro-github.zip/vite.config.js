import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['favicon.ico', 'icon-192.png', 'icon-512.png'],
      manifest: {
        name: 'ImóvelPro - Corretor Digital',
        short_name: 'ImóvelPro',
        description: 'App completo para corretores de imóveis',
        theme_color: '#F59E0B',
        background_color: '#0A0E1A',
        display: 'standalone',
        orientation: 'portrait',
        scope: '/',
        start_url: '/',
        icons: [
          {
            src: 'icon-192.png',
            sizes: '192x192',
            type: 'image/png'
          },
          {
            src: 'icon-512.png',
            sizes: '512x512',
            type: 'image/png'
          }
        ]
      },
      workbox: {
        globPatterns: ['**/*.{js,css,ico,png,svg}'], // removido html do cache estático
        skipWaiting: true,
        clientsClaim: true,
        // Rota /captacao NUNCA vai para cache — sempre busca da rede
        navigateFallback: '/index.html',
        navigateFallbackDenylist: [/^\/captacao/],
        runtimeCaching: [
          {
            // HTML de navegação: network-first (sempre tenta a rede primeiro)
            urlPattern: ({ request }) => request.mode === 'navigate',
            handler: 'NetworkFirst',
            options: {
              cacheName: 'html-cache',
              networkTimeoutSeconds: 5,
            },
          },
          {
            // JS/CSS/assets: cache-first para performance
            urlPattern: /\.(?:js|css|png|ico|svg)$/,
            handler: 'CacheFirst',
            options: {
              cacheName: 'assets-cache',
              expiration: { maxEntries: 60, maxAgeSeconds: 30 * 24 * 60 * 60 },
            },
          },
        ],
      }
    })
  ]
})
