// ─── NOTIFICACOES.JSX — Sistema completo de notificações Corretor Pró v9 ───
// Notificações push (Web Notifications API) + in-app toast + central de alertas

import { useState, useEffect, useRef, useCallback } from "react";
import { db } from "./firebase";
import {
  collection, addDoc, updateDoc, deleteDoc,
  doc, onSnapshot, serverTimestamp, query, where, orderBy, limit
} from "firebase/firestore";

const COLORS = {
  bg: "#0A0E1A", card: "#111827", cardBorder: "#1E293B",
  accent: "#F59E0B", green: "#10B981", red: "#EF4444",
  blue: "#3B82F6", purple: "#8B5CF6", text: "#F1F5F9",
  muted: "#64748B", surface: "#1E293B",
};

// ─── SONS DE NOTIFICAÇÃO ───
function tocarSomNotif(tipo = "padrao") {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const nota = (freq, start, dur, gain = 0.3, wave = "sine") => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.connect(g); g.connect(ctx.destination);
      osc.type = wave;
      osc.frequency.setValueAtTime(freq, ctx.currentTime + start);
      g.gain.setValueAtTime(0, ctx.currentTime + start);
      g.gain.linearRampToValueAtTime(gain, ctx.currentTime + start + 0.02);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + start + dur);
      osc.start(ctx.currentTime + start);
      osc.stop(ctx.currentTime + start + dur + 0.05);
    };

    if (tipo === "lead") {
      // 💰 Cha-ching! Novo lead
      nota(180, 0, 0.15, 0.5, "triangle");
      nota(1200, 0.05, 0.08, 0.4, "square");
      nota(1600, 0.10, 0.06, 0.3, "square");
      nota(900, 0.18, 0.25, 0.25, "sine");
    } else if (tipo === "urgente") {
      // ⚠️ Alerta urgente — duas bips altas
      nota(880, 0, 0.12, 0.4, "square");
      nota(880, 0.18, 0.12, 0.4, "square");
    } else if (tipo === "compromisso") {
      // 📅 Lembrete de compromisso — melodia suave
      nota(523, 0, 0.2, 0.3, "sine");
      nota(659, 0.22, 0.2, 0.3, "sine");
      nota(784, 0.44, 0.3, 0.35, "sine");
    } else if (tipo === "processo") {
      // 🏦 Processo atualizado
      nota(660, 0, 0.18, 0.35, "triangle");
      nota(880, 0.20, 0.28, 0.35, "triangle");
    } else {
      // 🔔 Padrão
      nota(523, 0, 0.15, 0.3, "sine");
      nota(659, 0.18, 0.2, 0.3, "sine");
    }
  } catch (e) {}
}

// ─── PUSH NOTIFICATIONS (Web Notifications API) ───
export function usePushNotificacoes() {
  const [permissao, setPermissao] = useState(
    typeof Notification !== "undefined" ? Notification.permission : "default"
  );

  const solicitarPermissao = useCallback(async () => {
    if (typeof Notification === "undefined") return false;
    const result = await Notification.requestPermission();
    setPermissao(result);
    return result === "granted";
  }, []);

  const enviarPush = useCallback((titulo, opcoes = {}) => {
    if (typeof Notification === "undefined") return;
    if (Notification.permission !== "granted") return;
    if (document.visibilityState === "visible") return; // só envia se app estiver em segundo plano

    try {
      const notif = new Notification(titulo, {
        icon: "/icon-192.png",
        badge: "/icon-192.png",
        tag: opcoes.tag || "corretor-pro",
        requireInteraction: opcoes.urgente || false,
        silent: false,
        ...opcoes,
      });
      notif.onclick = () => {
        window.focus();
        notif.close();
        if (opcoes.onClick) opcoes.onClick();
      };
      // Auto-fecha após 8s se não for urgente
      if (!opcoes.urgente) setTimeout(() => notif.close(), 8000);
    } catch (e) {}
  }, []);

  return { permissao, solicitarPermissao, enviarPush };
}

// ─── TOAST IN-APP ───
// Stack de toasts flutuantes no topo da tela
export function ToastContainer({ toasts, onDismiss }) {
  if (!toasts || toasts.length === 0) return null;

  const COR = {
    lead:        { bg: "#064E3B", border: "#10B981", text: "#6EE7B7", icone: "💰" },
    urgente:     { bg: "#450A0A", border: "#EF4444", text: "#FCA5A5", icone: "⚠️" },
    compromisso: { bg: "#1E3A8A", border: "#3B82F6", text: "#93C5FD", icone: "📅" },
    processo:    { bg: "#422006", border: "#F59E0B", text: "#FCD34D", icone: "🏦" },
    conquista:   { bg: "#1E1B4B", border: "#8B5CF6", text: "#C4B5FD", icone: "🏆" },
    padrao:      { bg: "#111827", border: "#64748B", text: "#94A3B8", icone: "🔔" },
  };

  return (
    <div style={{
      position: "fixed", top: 64, left: "50%", transform: "translateX(-50%)",
      width: "calc(100% - 24px)", maxWidth: 406,
      zIndex: 500, display: "flex", flexDirection: "column", gap: 8,
      pointerEvents: "none",
    }}>
      {toasts.slice(0, 3).map((t, idx) => {
        const c = COR[t.tipo] || COR.padrao;
        return (
          <div key={t.id} style={{
            background: c.bg,
            border: `2px solid ${c.border}`,
            borderRadius: 16, padding: "12px 14px",
            display: "flex", alignItems: "flex-start", gap: 12,
            boxShadow: `0 8px 32px rgba(0,0,0,0.7), 0 0 0 1px ${c.border}22`,
            animation: "slideDown 0.3s ease-out",
            pointerEvents: "auto",
            opacity: 1 - idx * 0.08,
            transform: `translateY(${idx * 4}px) scale(${1 - idx * 0.015})`,
            transition: "all 0.2s",
          }}>
            <span style={{ fontSize: 22, flexShrink: 0 }}>{t.icone || c.icone}</span>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ color: c.border, fontSize: 10, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 2 }}>
                {t.label || t.tipo}
              </div>
              <div style={{ color: COLORS.text, fontSize: 13, fontWeight: 700, lineHeight: 1.3 }}>{t.titulo}</div>
              {t.desc && <div style={{ color: c.text, fontSize: 11, marginTop: 2, lineHeight: 1.4, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{t.desc}</div>}
            </div>
            <button onClick={() => onDismiss(t.id)} style={{
              background: "transparent", border: "none", color: COLORS.muted,
              fontSize: 18, cursor: "pointer", padding: "0 2px", flexShrink: 0, lineHeight: 1,
            }}>×</button>
          </div>
        );
      })}
      <style>{`
        @keyframes slideDown {
          from { opacity: 0; transform: translateY(-20px) scale(0.95); }
          to   { opacity: 1; transform: translateY(0)    scale(1); }
        }
      `}</style>
    </div>
  );
}

// ─── HOOK PRINCIPAL: useNotificacoes ───
// Gerencia toda a lógica de notificações do app
export function useNotificacoes({ uid, imoveis = [], processos = [], setActive }) {
  const [toasts, setToasts]         = useState([]);
  const [historico, setHistorico]   = useState([]); // central de notificações
  const [naoLidas, setNaoLidas]     = useState(0);
  const [showCentral, setShowCentral] = useState(false);
  const { permissao, solicitarPermissao, enviarPush } = usePushNotificacoes();

  const toastIdRef  = useRef(0);
  const initDoneRef = useRef(false); // evita disparar na primeira carga

  // ── Adiciona toast ──
  const addToast = useCallback((toast) => {
    const id = ++toastIdRef.current;
    const entry = { id, ts: Date.now(), ...toast };
    setToasts(prev => [entry, ...prev].slice(0, 5));
    setHistorico(prev => [entry, ...prev].slice(0, 50));
    setNaoLidas(n => n + 1);

    // Toca som
    tocarSomNotif(toast.tipo || "padrao");

    // Envia push se em segundo plano
    enviarPush(toast.titulo, {
      body: toast.desc || "",
      tag: toast.tipo || "padrao",
      urgente: toast.tipo === "urgente",
    });

    // Auto-remove toast após 7s
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 7000);

    return id;
  }, [enviarPush]);

  const dismissToast = useCallback((id) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  // ── Listener: Novos leads via captação (whatsapp_leads) ──
  useEffect(() => {
    if (!uid) return;
    const q = query(collection(db, "whatsapp_leads"), where("uid", "==", uid));
    const idsVistos = { prev: null };

    const unsub = onSnapshot(q, snap => {
      const todos = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      const idsAgora = todos.map(l => l.id);

      if (idsVistos.prev !== null) {
        const novos = todos.filter(l => !idsVistos.prev.includes(l.id));
        novos.forEach(lead => {
          addToast({
            tipo: "lead",
            icone: "💰",
            label: "Novo Lead!",
            titulo: lead.nome || lead.remetente || "Novo lead chegou!",
            desc: `${lead.tipoNegocio || lead.interesse || "Lead via captação"} — toque para ver`,
            onNav: "crm",
          });
        });
      }
      idsVistos.prev = idsAgora;
    }, () => {});

    return () => unsub();
  }, [uid, addToast]);

  // ── Listener: Processos atualizados pelo correspondente ──
  useEffect(() => {
    if (!uid) return;
    const q = query(collection(db, "processos"), where("uid", "==", uid));
    const mapaAnterior = { prev: {} };

    const unsub = onSnapshot(q, snap => {
      const lista = snap.docs.map(d => ({ id: d.id, ...d.data() }));

      lista.forEach(p => {
        const ant = mapaAnterior.prev[p.id];
        if (ant &&
          p.updatedByCorrespondente &&
          (!ant.updatedByCorrespondente ||
            p.updatedByCorrespondente.seconds !== ant.updatedByCorrespondente?.seconds)
        ) {
          addToast({
            tipo: "processo",
            icone: "🏦",
            label: "Processo atualizado",
            titulo: `Correspondente atualizou: ${p.cliente}`,
            desc: `${p.banco} — Etapa ${p.etapa + 1}/6`,
            onNav: "bancario",
          });
        }
      });

      // Atualiza mapa anterior
      mapaAnterior.prev = Object.fromEntries(lista.map(p => [p.id, p]));
    }, () => {});

    return () => unsub();
  }, [uid, addToast]);

  // ── Listener: Compromissos do dia (avisa 30min antes) ──
  useEffect(() => {
    if (!uid) return;

    const verificarCompromissos = async () => {
      const hojeStr = new Date().toISOString().split("T")[0];
      const q = query(collection(db, "compromissos"), where("uid", "==", uid), where("data", "==", hojeStr));

      const unsub = onSnapshot(q, snap => {
        const agora = new Date();
        snap.docs.forEach(d => {
          const c = { id: d.id, ...d.data() };
          if (!c.hora) return;
          const [h, m] = c.hora.split(":").map(Number);
          const horario = new Date();
          horario.setHours(h, m, 0, 0);
          const diffMin = (horario - agora) / 60000;

          // Avisa 30 minutos antes (janela de 1 min para não repetir)
          if (diffMin > 29 && diffMin <= 30) {
            addToast({
              tipo: "compromisso",
              icone: "📅",
              label: "Lembrete",
              titulo: `Compromisso em 30 min: ${c.tipo || "Evento"}`,
              desc: c.titulo || c.cliente || c.hora,
              onNav: "agenda",
            });
          }
        });
      }, () => {});

      return unsub;
    };

    let unsub;
    verificarCompromissos().then(u => { unsub = u; });
    // Verifica a cada 60 segundos
    const interval = setInterval(() => {
      verificarCompromissos();
    }, 60000);

    return () => { unsub?.(); clearInterval(interval); };
  }, [uid, addToast]);

  // ── Listener: Novos negócios no CRM (leads adicionados manualmente) ──
  useEffect(() => {
    if (!uid) return;
    const q = query(collection(db, "negocios"), where("uid", "==", uid));
    const idsVistos = { prev: null };

    const unsub = onSnapshot(q, snap => {
      const lista = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      const idsAgora = lista.map(n => n.id);

      if (idsVistos.prev !== null) {
        const novos = lista.filter(n => !idsVistos.prev.includes(n.id));
        novos.forEach(n => {
          const valor = Number(n.valorEstimado) || 0;
          addToast({
            tipo: "lead",
            icone: valor >= 100000 ? "💰" : "🎯",
            label: valor >= 100000 ? "Lead de alto valor!" : "Novo Lead!",
            titulo: n.nome || "Novo lead no pipeline",
            desc: n.interesse
              ? (valor > 0 ? `${n.interesse} — R$ ${valor.toLocaleString("pt-BR")}` : n.interesse)
              : "Novo negócio no pipeline",
            onNav: "crm",
          });
        });
      }
      idsVistos.prev = idsAgora;
    }, () => {});

    return () => unsub();
  }, [uid, addToast]);

  return {
    toasts,
    dismissToast,
    historico,
    naoLidas,
    showCentral,
    setShowCentral,
    marcarTodasLidas: () => setNaoLidas(0),
    permissao,
    solicitarPermissao,
    addToast,
  };
}

// ─── CENTRAL DE NOTIFICAÇÕES (painel deslizante) ───
export function CentralNotificacoes({ historico, naoLidas, onClose, onMarcarLidas, onNav, permissao, solicitarPermissao }) {
  const COR = {
    lead:        { border: "#10B981", bg: "rgba(16,185,129,0.08)", icone: "💰" },
    urgente:     { border: "#EF4444", bg: "rgba(239,68,68,0.08)",  icone: "⚠️" },
    compromisso: { border: "#3B82F6", bg: "rgba(59,130,246,0.08)", icone: "📅" },
    processo:    { border: "#F59E0B", bg: "rgba(245,158,11,0.08)", icone: "🏦" },
    conquista:   { border: "#8B5CF6", bg: "rgba(139,92,246,0.08)", icone: "🏆" },
    padrao:      { border: "#64748B", bg: "rgba(100,116,139,0.08)", icone: "🔔" },
  };

  const formatTS = (ts) => {
    if (!ts) return "";
    const d = new Date(ts);
    const agora = new Date();
    const diffMin = Math.floor((agora - d) / 60000);
    if (diffMin < 1) return "agora";
    if (diffMin < 60) return `${diffMin} min atrás`;
    if (diffMin < 1440) return `${Math.floor(diffMin / 60)}h atrás`;
    return d.toLocaleDateString("pt-BR");
  };

  return (
    <div style={{
      position: "fixed", inset: 0, zIndex: 600,
      display: "flex", flexDirection: "column", alignItems: "flex-end",
    }}>
      {/* Overlay */}
      <div onClick={onClose} style={{
        position: "absolute", inset: 0,
        background: "rgba(0,0,0,0.6)",
      }} />

      {/* Painel */}
      <div style={{
        position: "relative", width: "100%", maxWidth: 430,
        height: "100%", background: COLORS.bg,
        borderLeft: `1px solid ${COLORS.cardBorder}`,
        display: "flex", flexDirection: "column",
        animation: "slideLeft 0.25s ease-out",
      }}>
        {/* Header */}
        <div style={{
          background: COLORS.card, borderBottom: `1px solid ${COLORS.cardBorder}`,
          padding: "16px 20px", display: "flex", alignItems: "center", gap: 12,
        }}>
          <button onClick={onClose} style={{
            background: COLORS.surface, border: "none", borderRadius: 8,
            width: 32, height: 32, color: COLORS.text, cursor: "pointer", fontSize: 18,
          }}>←</button>
          <div style={{ flex: 1 }}>
            <div style={{ color: COLORS.text, fontWeight: 800, fontSize: 16 }}>
              🔔 Notificações
            </div>
            {naoLidas > 0 && (
              <div style={{ color: COLORS.muted, fontSize: 12 }}>{naoLidas} não lida{naoLidas > 1 ? "s" : ""}</div>
            )}
          </div>
          {naoLidas > 0 && (
            <button onClick={onMarcarLidas} style={{
              background: "transparent", border: `1px solid ${COLORS.cardBorder}`,
              borderRadius: 8, padding: "5px 10px", color: COLORS.muted,
              fontSize: 11, fontWeight: 700, cursor: "pointer",
            }}>✓ Marcar lidas</button>
          )}
        </div>

        {/* Permissão push */}
        {permissao !== "granted" && (
          <div style={{
            margin: "12px 16px 0",
            background: "rgba(59,130,246,0.1)", border: "1px solid rgba(59,130,246,0.3)",
            borderRadius: 12, padding: "12px 14px",
          }}>
            <div style={{ color: COLORS.blue, fontWeight: 700, fontSize: 13, marginBottom: 6 }}>
              📲 Ativar notificações push
            </div>
            <div style={{ color: COLORS.muted, fontSize: 12, marginBottom: 10, lineHeight: 1.5 }}>
              Receba alertas mesmo com o app em segundo plano.
            </div>
            <button onClick={solicitarPermissao} style={{
              background: COLORS.blue, border: "none", borderRadius: 8,
              padding: "8px 16px", color: "#fff", fontWeight: 700, fontSize: 12, cursor: "pointer",
            }}>
              🔔 Ativar Notificações
            </button>
          </div>
        )}

        {/* Lista */}
        <div style={{ flex: 1, overflowY: "auto", padding: "12px 16px" }}>
          {historico.length === 0 ? (
            <div style={{ textAlign: "center", padding: "60px 20px", color: COLORS.muted }}>
              <div style={{ fontSize: 48, marginBottom: 16 }}>🔔</div>
              <div style={{ fontSize: 14, fontWeight: 600 }}>Nenhuma notificação ainda</div>
              <div style={{ fontSize: 12, marginTop: 6 }}>Suas notificações aparecerão aqui</div>
            </div>
          ) : historico.map((n, i) => {
            const c = COR[n.tipo] || COR.padrao;
            return (
              <div key={n.id} onClick={() => { if (n.onNav) { onNav(n.onNav); onClose(); } }}
                style={{
                  background: c.bg, border: `1px solid ${c.border}22`,
                  borderLeft: `3px solid ${c.border}`,
                  borderRadius: 12, padding: "12px 14px", marginBottom: 8,
                  cursor: n.onNav ? "pointer" : "default",
                  display: "flex", gap: 12, alignItems: "flex-start",
                }}>
                <span style={{ fontSize: 20, flexShrink: 0 }}>{n.icone || c.icone}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ color: COLORS.text, fontWeight: 700, fontSize: 13, lineHeight: 1.3, marginBottom: 2 }}>
                    {n.titulo}
                  </div>
                  {n.desc && (
                    <div style={{ color: COLORS.muted, fontSize: 11, lineHeight: 1.4, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {n.desc}
                    </div>
                  )}
                  <div style={{ color: COLORS.muted, fontSize: 10, marginTop: 4 }}>
                    {formatTS(n.ts)}
                  </div>
                </div>
                {n.onNav && (
                  <span style={{ color: c.border, fontSize: 14, flexShrink: 0, marginTop: 2 }}>→</span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <style>{`
        @keyframes slideLeft {
          from { transform: translateX(100%); opacity: 0; }
          to   { transform: translateX(0);    opacity: 1; }
        }
      `}</style>
    </div>
  );
}

// ─── BOTÃO DE NOTIFICAÇÕES (no header) ───
export function BotaoNotificacoes({ naoLidas, onClick }) {
  return (
    <button onClick={onClick} style={{
      background: COLORS.surface, border: "none", borderRadius: 8,
      width: 32, height: 32, cursor: "pointer", fontSize: 16,
      position: "relative", display: "flex", alignItems: "center", justifyContent: "center",
    }} title="Notificações">
      🔔
      {naoLidas > 0 && (
        <span style={{
          position: "absolute", top: -4, right: -4,
          background: "#EF4444", color: "#fff",
          fontSize: 9, fontWeight: 800, borderRadius: "50%",
          width: 16, height: 16, display: "flex", alignItems: "center", justifyContent: "center",
          lineHeight: 1,
        }}>
          {naoLidas > 9 ? "9+" : naoLidas}
        </span>
      )}
    </button>
  );
}

// ─── BANNER DE PERMISSÃO (aparece 1x após login) ───
export function BannerPermissaoPush({ permissao, onSolicitar, onDismiss }) {
  if (permissao === "granted" || permissao === "denied") return null;

  return (
    <div style={{
      position: "fixed", bottom: 72, left: "50%", transform: "translateX(-50%)",
      width: "calc(100% - 24px)", maxWidth: 406,
      background: "#0F172A", border: "1px solid #3B82F6",
      borderRadius: 16, padding: "14px 16px",
      display: "flex", alignItems: "center", gap: 12,
      boxShadow: "0 8px 32px rgba(0,0,0,0.6)",
      zIndex: 400,
      animation: "slideUp 0.3s ease-out",
    }}>
      <span style={{ fontSize: 28, flexShrink: 0 }}>📲</span>
      <div style={{ flex: 1 }}>
        <div style={{ color: COLORS.text, fontWeight: 700, fontSize: 13 }}>
          Ativar notificações?
        </div>
        <div style={{ color: COLORS.muted, fontSize: 11, marginTop: 2, lineHeight: 1.4 }}>
          Receba alertas de novos leads mesmo com o app fechado.
        </div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 6, flexShrink: 0 }}>
        <button onClick={onSolicitar} style={{
          background: "#3B82F6", border: "none", borderRadius: 8,
          padding: "6px 12px", color: "#fff", fontWeight: 800, fontSize: 11, cursor: "pointer",
        }}>Ativar</button>
        <button onClick={onDismiss} style={{
          background: "transparent", border: "none", color: COLORS.muted,
          fontSize: 11, cursor: "pointer",
        }}>Depois</button>
      </div>
      <style>{`
        @keyframes slideUp {
          from { transform: translateX(-50%) translateY(20px); opacity: 0; }
          to   { transform: translateX(-50%) translateY(0);    opacity: 1; }
        }
      `}</style>
    </div>
  );
}
