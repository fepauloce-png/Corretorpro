// ── sons.js — Sons do Corretor Pró ──────────────────────────────────────────────

// Guarda o AudioContext desbloqueado pelo primeiro toque do usuário
let _ctx = null;

function getCtx() {
  if (!_ctx) {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return null;
    _ctx = new AudioCtx();
  }
  if (_ctx.state === "suspended") {
    _ctx.resume(); // tenta desbloquear
  }
  return _ctx;
}

// Chama isso no primeiro clique/toque do usuário para desbloquear o áudio
export function desbloquearAudio() {
  const ctx = getCtx();
  if (ctx && ctx.state === "suspended") {
    ctx.resume();
  }
}

/**
 * Cha-ching! Toca quando chega lead ou assinatura é ativada.
 */
export function tocarSomDinheiro() {
  try {
    const ctx = getCtx();
    if (!ctx) return;

    const nota = (freq, inicio, dur, gain, tipo) => {
      const osc = ctx.createOscillator();
      const g   = ctx.createGain();
      osc.connect(g);
      g.connect(ctx.destination);
      osc.type = tipo || "sine";
      osc.frequency.setValueAtTime(freq, ctx.currentTime + inicio);
      g.gain.setValueAtTime(0.001, ctx.currentTime + inicio);
      g.gain.linearRampToValueAtTime(gain, ctx.currentTime + inicio + 0.015);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + inicio + dur);
      osc.start(ctx.currentTime + inicio);
      osc.stop(ctx.currentTime + inicio + dur + 0.05);
    };

    // Clique metálico de moeda + escala ascendente (cha-ching)
    nota(1400, 0.00, 0.06, 0.6, "square");
    nota(1000, 0.04, 0.08, 0.3, "square");
    nota(523,  0.12, 0.18, 0.5, "sine");
    nota(659,  0.24, 0.18, 0.5, "sine");
    nota(784,  0.36, 0.18, 0.5, "sine");
    nota(1047, 0.48, 0.35, 0.6, "sine");
    nota(1319, 0.56, 0.30, 0.4, "sine");
  } catch (e) {
    console.warn("Som bloqueado:", e.message);
  }
}

// ── WhatsApp global ──────────────────────────────────────────────────────────
let _waHandler = null;

export function registrarAbrirWhatsApp(fn) {
  _waHandler = fn;
}

export function abrirWhatsApp(url) {
  if (_waHandler) {
    _waHandler(url);
  } else {
    window.open(url, "_blank");
  }
}
