/**
 * CorrespondentePro.jsx
 * Tela exclusiva para o CORRESPONDENTE BANCÁRIO.
 *
 * Acesso via URL:  /?correspondente=<processoId>
 * (ou qualquer rota que o Root.jsx direcionar)
 *
 * O correspondente pode:
 *  - Ver dados do processo (cliente, banco, imóvel, valor)
 *  - Ver a lista de documentos anexados pelo corretor
 *  - Avançar etapas do processo
 *  - Adicionar observações / notas internas
 *  - Enviar mensagem WhatsApp ao corretor
 */

import { useState, useEffect } from "react";
import { db } from "./firebase";
import {
  doc, getDoc, onSnapshot, updateDoc, serverTimestamp, collection, query, where, getDocs,
} from "firebase/firestore";
import { tocarSomDinheiro, abrirWhatsApp } from "./sons";

// ─── Paleta (igual ao App principal) ────────────────────────────────────────
const C = {
  bg: "#0A0E1A", card: "#111827", border: "#1E293B",
  accent: "#F59E0B", green: "#10B981", red: "#EF4444",
  blue: "#3B82F6", purple: "#8B5CF6", text: "#F1F5F9",
  muted: "#64748B", surface: "#1E293B",
};

const ETAPAS = [
  "Solicitação",
  "Análise de Crédito",
  "Avaliação do Imóvel",
  "Aprovação",
  "Assinatura",
  "Liberação",
];

// ─── Micro-componentes ───────────────────────────────────────────────────────
function Card({ children, style = {} }) {
  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 16, padding: 20, ...style }}>
      {children}
    </div>
  );
}

function Btn({ children, onClick, color = "accent", full = false, disabled = false, style = {} }) {
  const bg = { accent: C.accent, green: C.green, blue: C.blue, red: C.red, surface: C.surface }[color] || C.accent;
  const fg = color === "surface" ? C.text : "#000";
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        background: disabled ? C.surface : bg, color: disabled ? C.muted : fg,
        border: "none", borderRadius: 12, padding: "11px 18px",
        fontWeight: 700, fontSize: 14, cursor: disabled ? "not-allowed" : "pointer",
        width: full ? "100%" : undefined, opacity: disabled ? 0.6 : 1, ...style,
      }}
    >
      {children}
    </button>
  );
}

function Badge({ color, children }) {
  const map = {
    green: { bg: "#064E3B", text: "#6EE7B7" },
    yellow: { bg: "#78350F", text: "#FCD34D" },
    blue: { bg: "#1E3A8A", text: "#93C5FD" },
    purple: { bg: "#4C1D95", text: "#C4B5FD" },
    red: { bg: "#7F1D1D", text: "#FCA5A5" },
  };
  const s = map[color] || map.blue;
  return (
    <span style={{ background: s.bg, color: s.text, padding: "3px 12px", borderRadius: 20, fontSize: 11, fontWeight: 700 }}>
      {children}
    </span>
  );
}

const etapaCor = ["blue", "yellow", "yellow", "purple", "green", "green"];

// ─── Componente principal ────────────────────────────────────────────────────
export default function CorrespondentePro({ processoId }) {
  const [proc, setProc]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [erro, setErro]       = useState("");
  const [salvando, setSalvando] = useState(false);
  const [nota, setNota]       = useState("");
  const [notas, setNotas]     = useState([]);
  const [avancando, setAvancando] = useState(false);
  const [sucesso, setSucesso] = useState("");
  const [menuAberto, setMenuAberto] = useState(false);
  const [todosProcessos, setTodosProcessos] = useState([]);
  const [procAtualId, setProcAtualId] = useState(processoId);
  const [clienteDocs, setClienteDocs] = useState([]);
  const [loadingClienteDocs, setLoadingClienteDocs] = useState(false);

  // ── 💰 Toca som de dinheiro quando o correspondente abre o link ──
  useEffect(() => {
    // Pequeno delay para garantir que o AudioContext seja criado após interação
    const timer = setTimeout(() => tocarSomDinheiro(), 800);
    return () => clearTimeout(timer);
  }, []); // roda apenas uma vez, ao montar

  // ── Carregar processo em tempo real (onSnapshot) ────────────────────────────
  useEffect(() => {
    if (!procAtualId) { setErro("Link inválido — ID do processo não informado."); setLoading(false); return; }
    const unsub = onSnapshot(
      doc(db, "processos", procAtualId),
      (snap) => {
        if (!snap.exists()) { setErro("Processo não encontrado."); setLoading(false); return; }
        const data = { id: snap.id, ...snap.data() };
        setProc(data);
        setNotas(data.notasCorrespondente || []);
        setLoading(false);
      },
      (e) => {
        setErro("Erro ao carregar processo: " + e.message);
        setLoading(false);
      }
    );
    return () => unsub(); // limpa listener ao sair
      // Quando proc carrega, busca todos os processos do mesmo corretor
    return () => {};
  }, [procAtualId]);

  // Busca todos os processos do corretor quando proc é carregado
  useEffect(() => {
    if (!proc?.uid) return;
    getDocs(query(collection(db, "processos"), where("uid", "==", proc.uid)))
      .then(snap => {
        const lista = snap.docs.map(d => ({ id: d.id, ...d.data() }))
          .sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
        setTodosProcessos(lista);
      });
  }, [proc?.uid]);

  // Docs do proprietário ficam direto no processo
  useEffect(() => {
    if (!proc) return;
    setClienteDocs(proc.docsProprietario || []);
    setLoadingClienteDocs(false);
  }, [proc]);

  // ── Avançar etapa ──────────────────────────────────────────────────────────
  const avancar = async () => {
    if (!proc || proc.etapa >= ETAPAS.length - 1) return;
    setAvancando(true);
    try {
      const novaEtapa = proc.etapa + 1;
      await updateDoc(doc(db, "processos", procAtualId), {
        etapa: novaEtapa,
        status: ETAPAS[novaEtapa],
        updatedAt: serverTimestamp(),
        ultimaAtualizacaoCorrespondente: serverTimestamp(),
        updatedByCorrespondente: serverTimestamp(),
      });
      setProc(p => ({ ...p, etapa: novaEtapa, status: ETAPAS[novaEtapa] }));
      flash("✅ Etapa avançada com sucesso!");
    } catch (e) { alert("Erro: " + e.message); }
    setAvancando(false);
  };

  // ── Adicionar nota ─────────────────────────────────────────────────────────
  const adicionarNota = async () => {
    if (!nota.trim()) return;
    setSalvando(true);
    try {
      const novaLista = [
        ...notas,
        { texto: nota.trim(), data: new Date().toLocaleString("pt-BR"), autor: "Correspondente" },
      ];
      await updateDoc(doc(db, "processos", procAtualId), {
        notasCorrespondente: novaLista,
        updatedAt: serverTimestamp(),
        ultimaAtualizacaoCorrespondente: serverTimestamp(),
        updatedByCorrespondente: serverTimestamp(),
      });
      setNotas(novaLista);
      setNota("");
      flash("📝 Nota salva!");
    } catch (e) { alert("Erro: " + e.message); }
    setSalvando(false);
  };

  // ── Flash de sucesso ───────────────────────────────────────────────────────
  const flash = (msg) => {
    setSucesso(msg);
    setTimeout(() => setSucesso(""), 3000);
  };

  // ── Notificar corretor via WhatsApp ────────────────────────────────────────
  const notificarCorretor = () => {
    if (!proc) return;
    const msg =
      `🏦 *Atualização do Processo*\n` +
      `👤 Cliente: ${proc.cliente}\n` +
      `🏠 Imóvel: ${proc.imovel}\n` +
      `📊 Etapa atual: *${ETAPAS[proc.etapa]}* (${proc.etapa + 1}/${ETAPAS.length})\n\n` +
      `_Mensagem enviada pelo correspondente via Corretor Pró_`;
    abrirWhatsApp(`https://wa.me/?text=${encodeURIComponent(msg)}`);
  };

  // ─── Telas ────────────────────────────────────────────────────────────────
  if (loading) return (
    <div style={{ background: C.bg, minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", fontFamily: "'Segoe UI', system-ui, sans-serif" }}>
      <div style={{ fontSize: 48, marginBottom: 16 }}>🏦</div>
      <div style={{ color: C.accent, fontWeight: 800, fontSize: 20 }}>Carregando processo...</div>
    </div>
  );

  if (erro) return (
    <div style={{ background: C.bg, minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", fontFamily: "'Segoe UI', system-ui, sans-serif", padding: 24 }}>
      <div style={{ fontSize: 56, marginBottom: 16 }}>⚠️</div>
      <div style={{ color: C.red, fontWeight: 700, fontSize: 18, textAlign: "center", marginBottom: 8 }}>Acesso inválido</div>
      <div style={{ color: C.muted, fontSize: 14, textAlign: "center" }}>{erro}</div>
    </div>
  );

  return (
    <div style={{ background: C.bg, minHeight: "100vh", maxWidth: 430, margin: "0 auto", fontFamily: "'Segoe UI', system-ui, sans-serif", paddingBottom: 40 }}>

      {/* ── Header ── */}
      <div style={{ background: C.card, borderBottom: `1px solid ${C.border}`, padding: "14px 16px", display: "flex", alignItems: "center", gap: 12, position: "sticky", top: 0, zIndex: 100 }}>
        <div style={{ width: 40, height: 40, borderRadius: 12, background: C.accent, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 22 }}>🏦</div>
        <div style={{ flex: 1 }}>
          <div style={{ color: C.text, fontWeight: 800, fontSize: 15 }}>Portal do Correspondente</div>
          <div style={{ color: C.muted, fontSize: 11 }}>Corretor Pró — acesso restrito</div>
        </div>
        {todosProcessos.length > 1 && (
          <button onClick={() => setMenuAberto(m => !m)}
            style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 10, padding: "8px 12px", color: C.text, fontSize: 13, fontWeight: 700, cursor: "pointer" }}>
            ☰ Processos ({todosProcessos.length})
          </button>
        )}
      </div>

      {/* ── Menu de processos ── */}
      {menuAberto && (
        <div style={{ background: C.card, borderBottom: `1px solid ${C.border}`, padding: "12px 16px" }}>
          <div style={{ color: C.muted, fontSize: 12, fontWeight: 700, marginBottom: 10, textTransform: "uppercase" }}>Selecionar Processo</div>
          {todosProcessos.map(p => (
            <div key={p.id} onClick={() => { setProcAtualId(p.id); setMenuAberto(false); setLoading(true); }}
              style={{ padding: "10px 14px", borderRadius: 10, marginBottom: 6, cursor: "pointer",
                background: p.id === procAtualId ? C.surface : "transparent",
                border: `1px solid ${p.id === procAtualId ? C.accent : C.border}` }}>
              <div style={{ color: p.id === procAtualId ? C.accent : C.text, fontWeight: 700, fontSize: 13 }}>
                👤 {p.cliente}
              </div>
              <div style={{ color: C.muted, fontSize: 11, marginTop: 2 }}>
                🏦 {p.banco} · 📊 {p.status || "Solicitação"}
              </div>
            </div>
          ))}
        </div>
      )}

      <div style={{ padding: "20px 16px" }}>

        {/* ── Flash de sucesso ── */}
        {sucesso && (
          <div style={{ background: "#064E3B", border: `1px solid ${C.green}`, borderRadius: 12, padding: "10px 16px", marginBottom: 16, color: "#6EE7B7", fontWeight: 700, fontSize: 14, textAlign: "center" }}>
            {sucesso}
          </div>
        )}

        {/* ── Dados do processo ── */}
        <Card style={{ marginBottom: 14 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
            <h2 style={{ color: C.text, margin: 0, fontSize: 17, fontWeight: 800 }}>📋 Processo Bancário</h2>
            <Badge color={etapaCor[proc.etapa] || "blue"}>{proc.status}</Badge>
          </div>
          {[
            ["👤 Cliente",  proc.cliente],
            ["🏦 Banco",    proc.banco],
            ["🏠 Imóvel",   proc.imovel],
            ["💰 Valor",    `R$ ${Number(proc.valor).toLocaleString("pt-BR")}`],
            ["📅 Abertura", proc.data],
          ].map(([k, v]) => (
            <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${C.border}` }}>
              <span style={{ color: C.muted, fontSize: 13 }}>{k}</span>
              <span style={{ color: C.text, fontSize: 13, fontWeight: 600, textAlign: "right", maxWidth: "60%" }}>{v}</span>
            </div>
          ))}
        </Card>

        {/* ── Andamento / etapas ── */}
        <Card style={{ marginBottom: 14 }}>
          <h3 style={{ color: C.text, margin: "0 0 16px", fontSize: 15, fontWeight: 700 }}>📊 Andamento do Processo</h3>
          {ETAPAS.map((etapa, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12 }}>
              <div style={{
                width: 32, height: 32, borderRadius: "50%", flexShrink: 0,
                background: i < proc.etapa ? C.green : i === proc.etapa ? C.accent : C.surface,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 13, fontWeight: 700,
                color: i <= proc.etapa ? "#000" : C.muted,
              }}>
                {i < proc.etapa ? "✓" : i + 1}
              </div>
              <div>
                <div style={{ color: i <= proc.etapa ? C.text : C.muted, fontSize: 13, fontWeight: i === proc.etapa ? 700 : 400 }}>{etapa}</div>
                {i === proc.etapa && <div style={{ color: C.accent, fontSize: 11 }}>← Etapa atual</div>}
              </div>
            </div>
          ))}

          {/* Barra de progresso */}
          <div style={{ display: "flex", gap: 3, height: 6, borderRadius: 3, overflow: "hidden", margin: "12px 0" }}>
            {ETAPAS.map((_, i) => (
              <div key={i} style={{ flex: 1, background: i <= proc.etapa ? C.green : C.surface }} />
            ))}
          </div>

          {proc.etapa < ETAPAS.length - 1 ? (
            <Btn full color="accent" onClick={avancar} disabled={avancando}>
              {avancando ? "⏳ Avançando..." : `✅ Avançar para: ${ETAPAS[proc.etapa + 1]}`}
            </Btn>
          ) : (
            <div style={{ textAlign: "center", padding: 14, background: "#064E3B", borderRadius: 12 }}>
              <span style={{ color: "#6EE7B7", fontWeight: 700, fontSize: 15 }}>🎉 Processo Concluído!</span>
            </div>
          )}
        </Card>

        {/* ── Documentos do cliente ── */}
        <Card style={{ marginBottom: 14 }}>
          <h3 style={{ color: C.text, margin: "0 0 14px", fontSize: 15, fontWeight: 700 }}>
            📎 Documentos do Cliente
          </h3>
          {(!proc.docs || proc.docs.length === 0) ? (
            <div style={{ textAlign: "center", padding: "20px 0", color: C.muted }}>
              <div style={{ fontSize: 36 }}>📂</div>
              <div style={{ fontSize: 13, marginTop: 8 }}>Nenhum documento anexado ainda.</div>
              <div style={{ fontSize: 11, color: C.accent, marginTop: 4 }}>O corretor irá adicionar os arquivos aqui.</div>
            </div>
          ) : (
            <>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                <span style={{ color: C.muted, fontSize: 12 }}>
                  {proc.docs.filter(d => d.url && !d.enviando).length} documento(s) disponível(eis)
                </span>
                {proc.docs.filter(d => d.url && !d.enviando).length > 1 && (
                  <button
                    onClick={() => {
                      proc.docs.filter(d => d.url && !d.enviando).forEach((d, i) => {
                        setTimeout(() => {
                          // Corrige URL de PDFs salvos como image/upload
                          const isPdf = !d.tipo?.includes("image");
                          let dlUrl = isPdf && true  // sempre corrige URL
                            ? d.url.replace("/raw/upload/", "/image/upload/")
                            : d.url;
                          const a = document.createElement("a");
                          a.href = dlUrl; a.download = d.nome; a.target = "_blank";
                          document.body.appendChild(a); a.click(); document.body.removeChild(a);
                        }, i * 600);
                      });
                    }}
                    style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 8, padding: "4px 10px", color: C.text, fontSize: 11, fontWeight: 700, cursor: "pointer" }}
                  >
                    ⬇️ Baixar Todos
                  </button>
                )}
              </div>
              {proc.docs.filter(d => d.url && !d.enviando).map((d, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 0", borderBottom: `1px solid ${C.border}` }}>
                  <span style={{ fontSize: 26 }}>{d.tipo?.includes("image") ? "🖼️" : "📄"}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ color: C.text, fontSize: 13, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{d.nome}</div>
                    <div style={{ color: C.muted, fontSize: 11 }}>{d.size} KB</div>
                  </div>
                  {d.url ? (
                    <div style={{ display: "flex", gap: 6 }}>
                      <button
                        onClick={() => window.open(d.url.replace("/raw/upload/", "/image/upload/"), "_blank")}
                        style={{ background: C.blue, border: "none", borderRadius: 8, padding: "6px 12px", color: "#fff", fontSize: 12, fontWeight: 700, cursor: "pointer" }}
                      >
                        👁️ Abrir
                      </button>
                      <button
                        onClick={() => {
                          // Corrige URL de PDFs salvos como image/upload, depois força download
                          const isPdf = !d.tipo?.includes("image");
                          let dlUrl = isPdf && true  // sempre corrige URL
                            ? d.url.replace("/raw/upload/", "/image/upload/")
                            : d.url;
                          const a = document.createElement("a");
                          a.href = dlUrl; a.download = d.nome; a.target = "_blank";
                          document.body.appendChild(a); a.click(); document.body.removeChild(a);
                        }}
                        style={{ background: "#064E3B", border: "none", borderRadius: 8, padding: "6px 12px", color: "#6EE7B7", fontSize: 12, fontWeight: 700, cursor: "pointer" }}
                      >
                        ⬇️ Baixar
                      </button>
                    </div>
                  ) : null}
                </div>
              ))}
            </>
          )}
        </Card>

        {/* ── Documentos do Proprietário ── */}
        <Card style={{ marginBottom: 14 }}>
          <h3 style={{ color: C.text, margin: "0 0 14px", fontSize: 15, fontWeight: 700 }}>
            🪪 Documentos do Proprietário
          </h3>
          <div style={{ color: C.muted, fontSize: 11, marginBottom: 12 }}>RG, CPF, comprovante de renda, escritura — enviados pelo corretor</div>
          {loadingClienteDocs ? (
            <div style={{ textAlign: "center", padding: "16px 0", color: C.muted, fontSize: 13 }}>⏳ Carregando...</div>
          ) : clienteDocs.length === 0 ? (
            <div style={{ textAlign: "center", padding: "20px 0", color: C.muted }}>
              <div style={{ fontSize: 36 }}>📋</div>
              <div style={{ fontSize: 13, marginTop: 8 }}>Nenhum documento do proprietário anexado ainda.</div>
            </div>
          ) : (
            <>
              <div style={{ color: C.muted, fontSize: 12, marginBottom: 10 }}>
                {clienteDocs.length} documento(s) disponível(eis)
              </div>
              {clienteDocs.map((d, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 0", borderBottom: `1px solid ${C.border}` }}>
                  <span style={{ fontSize: 26 }}>{d.tipo?.includes("image") ? "🖼️" : "📄"}</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ color: C.text, fontSize: 13, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{d.nome}</div>
                    <div style={{ color: C.muted, fontSize: 11 }}>{d.size} KB</div>
                  </div>
                  {d.url && (
                    <div style={{ display: "flex", gap: 6 }}>
                      <button
                        onClick={() => window.open(d.url.replace("/raw/upload/", "/image/upload/"), "_blank")}
                        style={{ background: C.blue, border: "none", borderRadius: 8, padding: "6px 12px", color: "#fff", fontSize: 12, fontWeight: 700, cursor: "pointer" }}
                      >👁️ Abrir</button>
                      <button
                        onClick={() => {
                          const a = document.createElement("a");
                          a.href = d.url.replace("/raw/upload/", "/image/upload/");
                          a.download = d.nome; a.target = "_blank";
                          document.body.appendChild(a); a.click(); document.body.removeChild(a);
                        }}
                        style={{ background: "#064E3B", border: "none", borderRadius: 8, padding: "6px 12px", color: "#6EE7B7", fontSize: 12, fontWeight: 700, cursor: "pointer" }}
                      >⬇️ Baixar</button>
                    </div>
                  )}
                </div>
              ))}
            </>
          )}
        </Card>

        {/* ── Notas do correspondente ── */}
        <Card style={{ marginBottom: 14 }}>
          <h3 style={{ color: C.text, margin: "0 0 14px", fontSize: 15, fontWeight: 700 }}>📝 Observações Internas</h3>
          <div style={{ marginBottom: 10 }}>
            <textarea
              value={nota}
              onChange={e => setNota(e.target.value)}
              placeholder="Adicione observações sobre o processo, pendências, aprovações parciais..."
              rows={3}
              style={{
                width: "100%", background: C.surface, border: `1px solid ${C.border}`,
                borderRadius: 10, padding: "10px 14px", color: C.text, fontSize: 14,
                boxSizing: "border-box", resize: "vertical", outline: "none",
                fontFamily: "'Segoe UI', system-ui, sans-serif",
              }}
            />
            <Btn full color="blue" onClick={adicionarNota} disabled={salvando || !nota.trim()} style={{ marginTop: 8 }}>
              {salvando ? "⏳ Salvando..." : "💾 Salvar Observação"}
            </Btn>
          </div>

          {notas.length > 0 && (
            <div style={{ marginTop: 12 }}>
              <div style={{ color: C.muted, fontSize: 11, fontWeight: 700, marginBottom: 8, textTransform: "uppercase" }}>Histórico</div>
              {[...notas].reverse().map((n, i) => (
                <div key={i} style={{ background: C.surface, borderRadius: 10, padding: "10px 14px", marginBottom: 8 }}>
                  <div style={{ color: C.text, fontSize: 13, lineHeight: 1.5 }}>{n.texto}</div>
                  <div style={{ color: C.muted, fontSize: 11, marginTop: 4 }}>🕐 {n.data} · {n.autor}</div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* ── Notificar corretor ── */}
        <Btn full color="green" onClick={notificarCorretor}>
          💬 Enviar Atualização ao Corretor (WhatsApp)
        </Btn>

        <div style={{ textAlign: "center", marginTop: 24, color: C.muted, fontSize: 11 }}>
          Corretor Pró · Portal do Correspondente Bancário
        </div>
      </div>
    </div>
  );
}
